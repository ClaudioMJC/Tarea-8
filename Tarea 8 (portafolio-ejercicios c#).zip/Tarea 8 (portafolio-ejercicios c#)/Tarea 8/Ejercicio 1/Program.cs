﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int cantidadNumeros = 20;  //declaramos variables que guarden la cantidad de valores 
            int positivos = 0;  
            int negativos = 0;
            int ceros = 0;

            Console.WriteLine("Ingrese {0} números:", cantidadNumeros);

            for (int i = 0; i < cantidadNumeros; i++)  // se solicitan los 20 números
            {
                int numero = int.Parse(Console.ReadLine());

                if (numero > 0)
                {
                    positivos++;  //dependiendo de lo ingresado sumará a positivo, negativo o ceros
                }
                else if (numero < 0)
                {
                    negativos++;
                }
                else
                {
                    ceros++;
                }
            }

            Console.WriteLine("Cantidad de números positivos: {0}", positivos);
            Console.WriteLine("Cantidad de números negativos: {0}", negativos);
            Console.WriteLine("Cantidad de ceros: {0}", ceros);
        }
    }
}
