﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio10
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int contadorNinos = 0;
            int contadorAdolescentes = 0;
            int contadorJovenes = 0;   // se declaran contadores para llevar un control de la cantidad de personas que ingresan
            int contadorAdultos = 0;
            int contadorAdultosMayores = 0;

            bool leerOtroAsistente = true;

            while (leerOtroAsistente)
            {
                Console.WriteLine("Ingrese la edad del asistente:");
                int edad = int.Parse(Console.ReadLine());   // se solicita la edad

                if (edad >= 1 && edad <= 10)
                {
                    contadorNinos++;
                }
                else if (edad >= 11 && edad <= 15)
                {
                    contadorAdolescentes++;
                }
                else if (edad >= 16 && edad <= 22)   //según la edad de cada individuo va aumentando la cantidad de personas
                {                                           //según la categoría por edad
                    contadorJovenes++;
                }
                else if (edad >= 23 && edad <= 65)
                {
                    contadorAdultos++;
                }
                else if (edad > 65)
                {
                    contadorAdultosMayores++;
                }

                Console.WriteLine("¿Desea ingresar la edad de otro asistente? (s/n)");
                string respuesta = Console.ReadLine();
                                                          //se pregunta cada vez al usuario si desea ingresar una persona mas
                if (respuesta.ToLower() != "s")   //si la respuesta es diferente a "s" se termina el programa
                {
                    leerOtroAsistente = false;
                }
            }

            Console.WriteLine("Cantidad de asistentes por categoría de edad:");
            Console.WriteLine("Niños: " + contadorNinos);
            Console.WriteLine("Adolescentes: " + contadorAdolescentes);    //se muestra las edades por rango de los asistentes
            Console.WriteLine("Jóvenes: " + contadorJovenes);
            Console.WriteLine("Adultos: " + contadorAdultos);
            Console.WriteLine("Adultos mayores: " + contadorAdultosMayores);
        }
    }

}

