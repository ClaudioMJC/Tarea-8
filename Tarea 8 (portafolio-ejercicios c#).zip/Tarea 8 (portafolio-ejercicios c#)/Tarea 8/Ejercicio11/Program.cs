﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio11
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int contadorPares = 0;
            int contadorCinco = 0;
            int contadorTotal = 0;

            while (contadorPares < 10 && contadorCinco < 4)
            {
                Console.WriteLine("Ingrese un número positivo:");  //se ingresa un numero
                int numero = int.Parse(Console.ReadLine());

                if (numero > 0) {  //solo números mayores a cero permiten ejecutar el resto del programa
                    if (numero % 2 == 0)
                    {
                        contadorPares++;  //si el mod del número ingresado es cero (osea es par) se aumeta contador de los pares
                    }

                    if (numero == 5)
                    {
                        contadorCinco++;  //si el número ingresado es igual a 5 sumamos un cinco al contador máximo de 4 cincos
                    }

                    contadorTotal++;

                }
                else
                {
                    Console.WriteLine("Error: ¡Debe ingresar un número positivo!"); 
                }

            }

            Console.WriteLine("Cantidad total de números leídos: " + contadorTotal);
            Console.ReadKey();
        }
    }

}

