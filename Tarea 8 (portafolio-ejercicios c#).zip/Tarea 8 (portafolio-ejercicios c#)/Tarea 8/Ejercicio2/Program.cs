﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio2
{
    internal class Program
    {
      
        static void Main(string[] args)
        {
            int mayoresIguales100 = 0;  //se declaran variables para contar mayores y menores de 100
            int menores100 = 0;
            bool deseaIngresarOtro = true;// se inicializa una variable booleana que controle el bucle

            while (deseaIngresarOtro)
            {
                Console.Write("Ingrese un número: ");
                int numero = int.Parse(Console.ReadLine());

                if (numero >= 100)  //se lleva un control de los valores mayores y menores a 100 y se aumentan los contadores
                {
                    mayoresIguales100++;
                }
                else
                {
                    menores100++;
                }

                Console.Write("¿Desea ingresar otro número? (s/n): "); //se pregunta si desea ingresar otro número
                string respuesta = Console.ReadLine();

                if (respuesta.ToLower() != "s") // si no desea ingresar más números se termina el programa
                {
                    deseaIngresarOtro = false;
                }
            }

            Console.WriteLine("Cantidad de números mayores o iguales a 100: {0}", mayoresIguales100); // se muestran los resultados
            Console.WriteLine("Cantidad de números menores a 100: {0}", menores100);
            Console.ReadKey();
        }
    }

}

