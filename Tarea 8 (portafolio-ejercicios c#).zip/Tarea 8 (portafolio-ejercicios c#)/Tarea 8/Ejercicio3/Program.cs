﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio3
{
    internal class Program
    {
     
        static void Main(string[] args)
        {
            int cantidadAlumnos = 10;
            int aprobados = 0;
            int reprobados = 0;

            for (int i = 1; i <= cantidadAlumnos; i++)
            {
                int nota;

                do
                {
                    Console.Write("Ingrese la nota del alumno {0}: ", i);  //se establece un bucle para evitar que se ingresen
                    nota = int.Parse(Console.ReadLine());                  //notas fuera de rango

                    if (nota < 0 || nota > 100)
                    {
                        Console.WriteLine("La nota debe estar entre 0 y 100. Inténtelo nuevamente.");
                    }
                } while (nota < 1 || nota > 100);

                if (nota >= 70)
                {                  //si las notas son correctas vamos sumando a los aprobados o reprobados
                    aprobados++;
                }
                else
                {
                    reprobados++;
                }
            }

            Console.WriteLine("Cantidad de alumnos aprobados: {0}", aprobados); // se muestran los resultados
            Console.WriteLine("Cantidad de alumnos reprobados: {0}", reprobados);
        }
    }

}



