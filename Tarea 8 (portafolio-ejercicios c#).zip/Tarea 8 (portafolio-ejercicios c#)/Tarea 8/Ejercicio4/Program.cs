﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int pares = 0;
            int impares = 0;
            int multiplosTres = 0;
            bool continuar = true;

            Console.WriteLine("Ingrese un número cualquiera (ingrese el número 0 para salir):");

            while (continuar)
            {
                int numero = int.Parse(Console.ReadLine());

                if (numero == 0)  //si ingresa cero cambia el valor de boola falso y termina el programa
                {
                    continuar = false;
                }
                else
                {
                    if (numero % 2 == 0) //si el mod del numero de ingresado es cero, es un numero par
                    {                    // de lo contrario es impar
                        pares++;
                    }
                    else
                    {
                        impares++;
                    }

                    if (numero % 3 == 0)   //si el numero es divisible entre 3, sería un multiplo de tres
                    {
                        multiplosTres++;
                    }
                }
            }

            Console.WriteLine("Cantidad de números pares: {0}", pares);
            Console.WriteLine("Cantidad de números impares: {0}", impares);
            Console.WriteLine("Cantidad de números múltiplos de tres: {0}", multiplosTres);
        }
    }

}

