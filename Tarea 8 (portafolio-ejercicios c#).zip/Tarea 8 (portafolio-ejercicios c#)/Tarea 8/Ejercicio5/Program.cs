﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio5
{
class Program
    {
        static void Main(string[] args)
        {
            int numerosLeidos = 0;
            int numerosNegativos = 0;

            Console.WriteLine("Ingrese un número: (cuando haya ingresado 5 números negativos se termina el programa");

            while (numerosNegativos < 5)
            {
                int numero = int.Parse(Console.ReadLine());
                numerosLeidos++;  //leemos el número de entrada y aumentamos la cantidad de números ingresados

                if (numero < 0)
                {
                    numerosNegativos++; //aumentamos los número negativos
                }
            }

            Console.WriteLine("Cantidad total de números leídos: {0}", numerosLeidos);
            Console.WriteLine();
        }
    }

}

