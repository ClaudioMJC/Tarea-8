﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio6
{
    internal class Program

    {
        static void Main(string[] args)
        {
            int suma = 0;

            Console.WriteLine("Ingrese 10 números:"); //se socilitan los números

            for (int i = 0; i < 10; i++)
            {
                int numero = int.Parse(Console.ReadLine()); 
                suma += numero; //se van sumando hasta que se hayan ingresado los 10 números
            }

            Console.WriteLine("La suma de los 10 números es: {0}", suma);
        }
    }

}



