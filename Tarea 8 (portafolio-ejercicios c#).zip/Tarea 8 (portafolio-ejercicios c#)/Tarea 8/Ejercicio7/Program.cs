﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio7
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int cantidadNumeros = 10;
            int sumaPares = 0;

            Console.WriteLine("Ingrese {0} números:", cantidadNumeros);  

            for (int i = 1; i <= cantidadNumeros; i++)
            {
                Console.Write("Número {0}: ", i);
                int numero = int.Parse(Console.ReadLine());

                if (numero % 2 == 0)    //si  el mod del numero ingresado es cero se suma
                {
                    sumaPares += numero;
                }
            }

            Console.WriteLine("La suma de los números pares es: {0}", sumaPares);
            Console.ReadKey();
        }
    }

}

