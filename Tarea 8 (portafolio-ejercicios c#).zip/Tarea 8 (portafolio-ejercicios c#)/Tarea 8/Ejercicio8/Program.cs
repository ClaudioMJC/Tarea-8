﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio8
{
    internal class Program
    {
        static void Main(string[] args)
        {
            
            double sumaTotal = 0;
            int contador = 0;

            Console.WriteLine("Ingrese un número cualquiera (ingrese el número 0 para salir):");

            while (true)
            {
                Console.Write("Número: ");
                int numero = int.Parse(Console.ReadLine());

                if (numero == 0)
                {
                    break;
                }

                sumaTotal += numero;  //cada vez que se ingrese un número se va sumando junto con el anterior
                contador++;  //el contador aumenta tambien
            }

            if (contador > 0)    //se termina el programa y se da el resultado del promedio  y de la suma total
            {
                double promedio = sumaTotal / contador;  
                Console.WriteLine("La suma total de los números es: {0}", sumaTotal);
                Console.WriteLine("El promedio de los números es: {0}", promedio);
            }
            else
            {
                Console.WriteLine("No se ingresaron números.");
            }
            Console.ReadKey();
        }
    }

}

