﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio9
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int contador = 0; // Variable para contar la cantidad de números ingresados (excluyendo el múltiplo de 5)
            int numero;

            Console.WriteLine("Ingrese los números (ingrese un múltiplo de 5 para terminar):");

            do          //si un número ingresado es divisible entre 5 sin dejar residuo, se considera un múltiplo de 5.
            {             //por ejemplo numero 25
                Console.Write("Número: ");
                numero = int.Parse(Console.ReadLine()); // Lee el número ingresado por el usuario

                if (numero % 5 != 0) // Verifica si el número no es un múltiplo de 5
                {
                    contador++; // Incrementa el contador si el número no es múltiplo de 5
                }

            } while (numero % 5 != 0); // Continúa solicitando números hasta que se ingrese un múltiplo de 5

            Console.WriteLine("Cantidad de números ingresados: {0}", contador); // Muestra la cantidad de números ingresados (excluyendo el múltiplo de 5)
            Console.ReadKey();
        }
    }

}

